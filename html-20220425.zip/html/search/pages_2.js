var searchData=
[
  ['폴더_20설명',['폴더 설명',['../page_dir.html',1,'']]],
  ['효과_20번호',['효과 번호',['../page_effectid.html',1,'']]],
  ['함수_28pk_3a_3aset_5ffunc_29_20설명',['함수(pk::set_func) 설명',['../page_func.html',1,'']]],
  ['패치노트',['패치노트',['../page_patchnote.html',1,'']]]
];
