var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstuvwxyzìí",
  1: "abcdefghiklmoprstuv",
  2: "p",
  3: "p",
  4: "abcdefghiklmnopqrstuvwy",
  5: "_abcdefghiklmnoprstuvwxyz",
  6: "bcdeilmnpstu",
  7: "np",
  8: "mìí"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "모두",
  1: "클래스",
  2: "네임스페이스들",
  3: "파일들",
  4: "함수",
  5: "변수",
  6: "타입정의",
  7: "매크로",
  8: "페이지들"
};

