var searchData=
[
  ['face_5fcutin',['face_cutin',['../namespacepk.html#a1b2fc0e4885215aa546d0f639b3fb3ab',1,'pk::face_cutin(int id, int time=1500) NOEXCEPT'],['../namespacepk.html#a8334537580841aa2eab16c8514bcbe30',1,'pk::face_cutin(unit unit)']]],
  ['facility_5fselector',['facility_selector',['../namespacepk.html#ab32eff7dcc685bd1029fe3dac643b893',1,'pk']]],
  ['fade',['fade',['../namespacepk.html#ac3e7c4f39b11455dcfd6ad2fd9087dc5',1,'pk::fade(int value, int duration=1000)'],['../namespacepk.html#a8516e258a37ddd5bef1ad79bff1a790a',1,'pk::fade(uint8 r, uint8 g, uint8 b, uint8 a, int duration)']]],
  ['force_5fselector',['force_selector',['../namespacepk.html#ae594a548e7352015b28892577d3a5f51',1,'pk']]],
  ['format',['format',['../namespacepk.html#a3bcf6bc97eec23f335f76d4be6983f64',1,'pk']]]
];
