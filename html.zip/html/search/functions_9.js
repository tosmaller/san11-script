var searchData=
[
  ['kill',['kill',['../namespacepk.html#a24c37c1b0fbec36d2125700a44fe5741',1,'pk::kill(building@ self, bool effect=true) NOEXCEPT'],['../namespacepk.html#a99271b0844cba1aceeb2574264c7da04',1,'pk::kill(force@ self, bool take_over=false, force@ by=null) NOEXCEPT'],['../namespacepk.html#a42ccfb85fcdd20e14e89c412d48ceaf1',1,'pk::kill(item@ self) NOEXCEPT'],['../namespacepk.html#a65396c276eaef503f6a9027c3895faa7',1,'pk::kill(person@ self, person@ by=null, hex_object@ where=null, person@ successor=null, int type=0) NOEXCEPT'],['../namespacepk.html#a0f3b3dbbdabeda087bbfa6a3433c5ef3',1,'pk::kill(unit@ self, unit@ by=null, bool melee=false, bool increase_hobaku_chance=false) NOEXCEPT']]]
];
